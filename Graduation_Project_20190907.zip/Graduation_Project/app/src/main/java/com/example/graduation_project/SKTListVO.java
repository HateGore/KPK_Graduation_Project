package com.example.graduation_project;

public class SKTListVO {
    private String start_station_name;
    private String destination_station_name;
    private String start_station_line;
    private String station_remaining;


    public String getStart_station_name() {
        return start_station_name;
    }

    public void setStart_station_name(String start_station_name) {
        this.start_station_name = start_station_name;
    }

    public String getDestination_station_name() {
        return destination_station_name;
    }

    public void setdestination_station_name(String destination_station_name) {
        this.destination_station_name = destination_station_name;
    }

    public String getStart_station_line() {
        return start_station_line;
    }

    public void setStart_station_line(String start_station_line) {
        this.start_station_line = start_station_line;
    }

    public String getStation_remaining() {
        return station_remaining;
    }

    public void setStation_remaining(String station_remaining) {
        this.station_remaining = station_remaining;
    }


}
