package com.example.graduation_project;

public class TresureSetting {
    private boolean turn_able = false;

    public void setTurn_able(boolean turn_able) {
        this.turn_able = turn_able;
    }

    public boolean getTurn_able() {
        return turn_able;
    }
}
